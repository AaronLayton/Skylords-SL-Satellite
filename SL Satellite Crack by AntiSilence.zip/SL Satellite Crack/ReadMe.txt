SL Satellite Crack by AntiSilence - https://twitter.com/AntiSilence666
Cracked with permission from the author - https://twitter.com/AaronLayton

1) Install SL Satellite
2) Overwrite satellite.exe with this version
3) Run and just click Register to bypass registration

This doesn't stop the register dialogue from popping up on application start, it just bypasses the code check.